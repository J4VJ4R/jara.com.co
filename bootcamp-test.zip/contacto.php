<?php
  $servidor="localhost";
  $usuario="jaracomc_web";
  $dataBase="jaracomc_web";
  $clave="4dministrador*";

  $enlace = mysqli_connect($servidor, $usuario, $clave, $dataBase);

  if(!$enlace){
    echo"error en la conexión";
  }
?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport"
    content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="robots" content="noindex,nofollow">
  <title>JARA ></title>
  <meta name="description"
    content="Servidio de desarrollo web, consultoría informática y mantenimiento de equipos de cómputo">
  <!-- Icons and favicons -->
  <link rel="icon" type="image/png" href="img/logo.png">
  <link rel="stylesheet" href="css/icomoon/style.css">
  <!-- STYLES CSS -->
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/normalize.css">

</head>

<body>
  <!-- Section hero -->
  <!-- Section Header -->
  <header>
    <div class="container-fluid container-fluid--relative">
      <!-- section header -->
      <div class="container js-header-nav">
        <div class="navbar ">
          <div class="brand">
            <div class="brand__toggle">
              <a href="#" class="brand__menu-on js-brand-menu-on js-menu-on brand__menu-on--white"
                aria-label="touch it to close or open menu">
                <span></span>
                <span></span>
                <span></span>
              </a>
            </div>
          </div>
          <nav class="navbar__nav">
            <ul class="navbar__list">
              <li class="navbar__item"><a class="navbar__link" href="home.html">Inicio</a></li>
              <li class="navbar__item"><a class="navbar__link" href="quienessomos.html">Quienes Somos</a></li>
              <li class="navbar__item"><a class="navbar__link" href="quehacemos.html">Que Hacemos</a></li>
              <li class="navbar__item"><a class="navbar__link" href="portafolio.html">Portafolio</a></li>
              <li class="navbar__item navbar__item--padding"><a class="navbar__link" href="contacto.html">Contacto</a></li>
            </ul>
          </nav>
          <a class="navbar__link-logo" href="home.html" aria-label="Logo landify company">
            <img src="./img/logocopia.png" alt="logo jara" height="50">
          </a>
          <ul class="social-media">
            <li class="social-media__item"><a class="social-media__link" href="#"><span
                  class="icon-instagram social-media__icon social-media__icon--turquoise"></span></a></li>
            <li class="social-media__item"><a class="social-media__link" href="#"><span
                  class="icon-facebook social-media__icon social-media__icon--turquoise"></span></a></li>
            <li class="social-media__item"><a class="social-media__link" href="#"><span
                  class="icon-twitter social-media__icon social-media__icon--turquoise"></span></a></li>
            <li class="social-media__item"><a class="social-media__link" href="#"><span
                  class="icon-youtube social-media__icon social-media__icon--turquoise"></span></a></li>
          </ul>
        </div>
        
      </div>
      <!-- //section banner -->
       

    </div>
  </header>
  <!-- //section main -->
  <main>
   
   <!-- CONTACT US SECTION -->
   <div class="container contact-us contact-us-width">
    <div class="row">
        <form action=""  class="contact-inputs text-left mr-1 ml-1 text-center">
            <h3 class="title-conctact-us">Contáctanos</h3>
                <input type="text" placeholder="Nombre" class="group-imputs-contacts">
                <input type="email" placeholder="Correo" class="group-imputs-contacts">
                <input type="text" placeholder="Tu mensaje" class="group-imputs-contacts">
            <button class="btn-contact">Enviar</button>
        </form>
    </div>
</div>
    
    
    
    
  </main>
  <!-- section footer -->
  <footer>
    <div class="footer-container-fluid">
      <div class="container">
        <div class="company-support">
          <ul class="company-support__list">
            <li class="company-support__item company-support__item--title">Nuestra empresa</li>
            <li class="company-support__item"> <a class="company-support__link" href="#js-text-box25">Quienes somos</a> </li>
            <li class="company-support__item"> <a class="company-support__link" href="#">Blog</a> </li>
            <!-- <li class="company-support__item"> <a class="company-support__link" href="#">Servicios</a></li> -->
            <!-- <li class="company-support__item"> <a class="company-support__link" href="#">Contáctanos</a></li> -->
          </ul>
          <ul class="company-support__list">
            <li class="company-support__item company-support__item--title">Soporte técnico</li>
            <li class="company-support__item"> <a class="company-support__link" href="portafolio.html">Portafolio</a></li>
            <!-- <li class="company-support__item"> <a class="company-support__link" href="#">Safety Center</a></li>
            <li class="company-support__item"> <a class="company-support__link" href="#">Community Guidelines</a></li> -->
          </ul>
          <ul class="company-support__list" id="contact">
            <li class="company-support__item company-support__item--title">Contactos</li>
            <li class="company-support__item"> <a class="company-support__link" href="#">email: info@jara.com.co</a></li>
            <li class="company-support__item"> <a class="company-support__link" href="#">celular y whatsapp: 3176787316</a></li>
          </ul>
          <!-- <div class="stores-footer stores-footer--show-on-desktop">
            <h3 class="stores-footer__title">Install App</h3>
            <img class="stores-footer__img-1 stores-footer__img-1--align" src="./img/google-play-footer.png"
              alt="google play store">
            <img class="stores-footer__img-2 stores-footer__img-2--align" src="./img/app-store-footer.png"
              alt="app store">
          </div> -->
          <ul class="social-media social-media--hidden-desktop">
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-instagram social-media__icon social-media__icon--show"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-facebook social-media__icon social-media__icon--show"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-twitter social-media__icon social-media__icon--show"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-youtube social-media__icon social-media__icon--show"></span></a></li>
          </ul>

        </div>
        <!-- <div class="stores-footer">
          <h3 class="stores-footer__title">Install App</h3>
          <img class="stores-footer__img-1" src="./img/google-play.png" alt="google play store">
          <img class="stores-footer__img-2" src="./img/app-store.png" alt="app store">
        </div> -->
      </div>
    </div>
    <div class="footer-container-fluid footer-container-fluid--line-gray">
      <div class="container ">
        <div class="copyright">
          <p class="copyright__description">© 2021 JARA > Desarollo web - Todos los derechos reservados </p>
          <ul class="social-media social-media--desktop-show social-media--on-footer">
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-instagram social-media__icon social-media__icon--gray"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-facebook social-media__icon social-media__icon--gray"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-twitter social-media__icon social-media__icon--gray"></span></a></li>
            <li class="social-media__item social-media__item--align-footer"><a class="social-media__link" href="#"><span
                  class="icon-youtube social-media__icon social-media__icon--gray"></span></a></li>
          </ul>
        </div>
      </div>
    </div>

  </footer>
  <!-- jquery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!-- Js-->
  <script src="js/project.js"></script>
</body>

</html>